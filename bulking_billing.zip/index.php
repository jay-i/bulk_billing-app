<!DOCTYPE html>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>
<h1>Bulk billing</h1>
<ol>
<li>The system will use AJAX and JavaScript timing to send request at intervals</li>
<li>At each request sent to the server-side, 10 field will be selected from the database and the used to send request to the API end-point</li>
<li>After the request is successful the callback function recalls the function recursively and stores the last id of the user details</li>
<li>This will continue till the all database entries are completed.</li>
<li>The script will send request 1,000 times to complete all billed user which will take 1,6 X 1000 = 1600seconds to complete</li>
<li>To complete for 100,000 users. The script the pull 12 users each for each request to complete within 4 hours</li>

</ol>

<div id="demo">
</div>

<input id="last_id" />
<script>
	//var myVar = setInterval(myTimer, 1000);
 var last_id = document.getElementById("last_id").value;
	function bill() {
		var d = new Date();
		document.getElementById("demo").innerHTML = d.toLocaleTimeString();
    $.post("biller.php",
    {
        name: "Donald Duck",
        city: "Duckburg"
    },
    function(data, status){
		alert('billed');
				bill();
				
			});

	}

	
</script>

<button onclick="clearInterval(myVar)">Stop time</button>
<button onclick="bill()">Start Billing</button>

</body>
</html>