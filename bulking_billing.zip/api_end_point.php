<?php
sleep(1.6);
header('Content-Type: application/json');
$myObj->status = "OK";
$myObj->response = "successful";
$myObj->response_time = "ddfsf";

$myJSON = json_encode($myObj);

echo $myObj->response;